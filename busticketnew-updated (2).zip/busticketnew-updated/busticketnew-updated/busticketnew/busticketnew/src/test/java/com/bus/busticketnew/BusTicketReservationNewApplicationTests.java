package com.bus.busticketnew;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BusTicketReservationNewApplicationTests {

	@Test
	void contextLoads() {
	}

}
